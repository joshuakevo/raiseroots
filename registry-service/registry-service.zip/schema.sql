-- ElTech Credit Registry schema. Run once in the registry's own MySQL database.

CREATE TABLE IF NOT EXISTS lenders (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(150) NOT NULL,
    api_key_hash  CHAR(64)     NOT NULL UNIQUE,
    is_active     TINYINT(1)   NOT NULL DEFAULT 1,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row per loan per lender. national_id is normalised (uppercase, letters/digits only)
-- so the same ID typed differently by two lenders still matches.
CREATE TABLE IF NOT EXISTS credit_records (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lender_id         INT UNSIGNED NOT NULL,
    loan_ref          VARCHAR(64)  NOT NULL,
    national_id       VARCHAR(50)  NOT NULL,
    client_name       VARCHAR(150) NOT NULL DEFAULT '',
    status            VARCHAR(20)  NOT NULL,
    principal         DECIMAL(15,2) NOT NULL DEFAULT 0,
    outstanding       DECIMAL(15,2) NOT NULL DEFAULT 0,
    disbursed_on      DATE NULL,
    days_in_arrears   INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at        DATETIME     NOT NULL,
    UNIQUE KEY uq_lender_loan (lender_id, loan_ref),
    KEY idx_nid (national_id),
    CONSTRAINT fk_records_lender FOREIGN KEY (lender_id) REFERENCES lenders(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Who looked up whom, and when (audit trail for data-protection queries).
CREATE TABLE IF NOT EXISTS lookup_log (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lender_id         INT UNSIGNED NOT NULL,
    national_id       VARCHAR(50)  NOT NULL,
    matches           INT UNSIGNED NOT NULL DEFAULT 0,
    created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_lookup_lender (lender_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
